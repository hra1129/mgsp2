===============================================================================

                              美咲フォント BDF 版

===============================================================================

　美咲フォント BDF 版は X11 BDF 形式のフォントです。
　X window system 等で利用できます。


●アーカイブの内容
＊misaki.txt
　美咲フォントのマニュアル

＊readme.txt
　美咲フォント BDF 版のマニュアル (このファイル)

＊misaki_gothic.bdf
　美咲ゴシック BDF 版
　(XLFD: -Kadoma-MisakiGothic-Regular-R-Normal--8-80-75-75-C-79-ISO10646-1)

＊misaki_mincho.bdf
　美咲明朝 BDF 版
　(XLFD: -Kadoma-MisakiMincho-Regular-R-Normal--8-80-75-75-C-79-ISO10646-1)

＊misaki_gothic_2nd.bdf
　美咲ゴシック第2 BDF 版
　(XLFD: -Kadoma-MisakiGothic2nd-Regular-R-Normal--8-80-75-75-C-79-ISO10646-1)


●ライセンス
　アーカイブ同梱の「misaki.txt」の内容に従うものとします。
