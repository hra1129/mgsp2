dir *.mgs > mgslist.txt
